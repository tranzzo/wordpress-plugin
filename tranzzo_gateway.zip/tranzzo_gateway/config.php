<?php

if (!defined('ABSPATH')){
    exit;
}

//Global payment title for this plugin
define('TPG_TITLE', 'TRANZZO');
